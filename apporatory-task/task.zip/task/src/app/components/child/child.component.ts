import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  constructor() { }
  @Input() childMessage: string;
  @Input() childMessage1: string;
  @Input() childMessage2: string;
  message:string;
  ngOnInit(): void {
  }

}
