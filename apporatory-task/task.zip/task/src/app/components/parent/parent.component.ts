import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  userData: any[]
  constructor() { }
  parentMessage = "message from parent";
  parentMessageId = 1;
  parentMessageName = "Shaun";
  parentMessageAge = 25;

  ngOnInit(): void {
  }
  
  public myData:Array<object> = [
    {id: 10000, name: 'Shaun Marsh', age:84},
    {id: 20000, name: 'Meacheal Vaugh',age:45},
    {id: 30000, name: 'Rahul Sharma',age:16},
    {id: 40000, name: 'Adam Zampa',age:66},

];
sendData(data):any{
  // alert(data)
  this.parentMessageId=data.id;
  this.parentMessageName=data.name;
  this.parentMessageAge=data.age;
}
}
